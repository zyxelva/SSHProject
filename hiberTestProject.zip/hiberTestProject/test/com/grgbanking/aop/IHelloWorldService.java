/**

* <p>Title: dddd.java</p>

* <p>Description: </p>

* <p>Copyright: Copyright (c) 2017</p>

* <p>Company: zyx@taeyeon.cn</p>

* @author KEN

* @date 2018年2月11日

* @version 1.0

*/

package com.grgbanking.aop;

/**
 * @author KEN
 *
 */
public interface IHelloWorldService {
    /**
     *
     * 功能描述: <br>
     * 〈HelloWorldService层〉
     *
     * @since [1.0.0](可选)
     */
    public String SayHelloWorld();
}
