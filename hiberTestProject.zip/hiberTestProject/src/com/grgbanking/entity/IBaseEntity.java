package com.grgbanking.entity;

public interface IBaseEntity {
	public String toJsonString();
}
